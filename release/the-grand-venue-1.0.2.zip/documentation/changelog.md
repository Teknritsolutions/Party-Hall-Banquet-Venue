﻿# Changelog

## 1.0.0 — 16 November 2026

- Added two original ten-section homepages and the complete public/authentication/utility page collection.
- Added all 11 client and 13 admin dashboard screens with a shared browser-local demo store.
- Added booking, availability, simulated installments, printable invoice, CRUD management, inbox, notification and report demonstrations.
- Added five charts, CSV export, theme/direction persistence, responsive navigation, gallery lightbox and filters.
- Generated and locally optimized 54 unique banquet photographs; added original arch branding and SVG/PNG application icons.
- Added installation, customization, dashboard, integration, image, credits and QA documentation.

## 1.0.1 — 16 November 2026

- Rebuilt the shared public header as one aligned row, following the reviewed reference's spacing principles.
- Added a prominent Client login action and a final Dashboard dropdown with client/login/admin destinations.
- Replaced the mobile dropdown panel with a responsive navigation drawer, backdrop, close control, keyboard handling and scroll lock.
- Refined hero heading scale and balanced section-heading wrapping.
- Verified 832 public-page layout combinations and all 57 existing workflow/edge assertions.

## 1.0.2 — 16 November 2026

- Reviewed the live Baby & Kids Clothing homepage, About, Shop and Contact typography and header interaction behavior.
- Added a shared typography stylesheet covering public pages, forms, authentication, utilities, client/admin workspaces and charts.
- Matched the measured 16px body, 15px navigation, 50/32px major heading and 20–24px card-title hierarchy.
- Added desktop hover dropdowns, keyboard submenu access, a sticky 85px desktop/68px mobile header and a full-width mobile navigation panel.
- Retained the venue's burgundy/champagne branding, client login and dashboard workflows.
