﻿# Changelog

## 1.0.0 — 16 November 2026

- Added two original ten-section homepages and the complete public/authentication/utility page collection.
- Added all 11 client and 13 admin dashboard screens with a shared browser-local demo store.
- Added booking, availability, simulated installments, printable invoice, CRUD management, inbox, notification and report demonstrations.
- Added five charts, CSV export, theme/direction persistence, responsive navigation, gallery lightbox and filters.
- Generated and locally optimized 54 unique banquet photographs; added original arch branding and SVG/PNG application icons.
- Added installation, customization, dashboard, integration, image, credits and QA documentation.
