﻿const fs = require("node:fs");
const path = require("node:path");
const read = (name) => JSON.parse(fs.readFileSync("documentation/" + name, "utf8"));
const stat = read("static-test-results.json");
const browser = read("browser-test-results.json");
const workflows = read("workflow-test-results.json");
const edges = read("edge-test-results.json");
const access = read("accessibility-test-results.json");
const photos = fs.readdirSync("assets/images").filter((f) => f.endsWith(".webp")).length;
const text = `# Verification report

Verified on 16 November 2026 using installed Google Chrome through Playwright, at http://127.0.0.1:4173.

## Results

| Check | Verified result |
|---|---|
| Required pages | 45: 21 public/auth/utility pages + 11 client + 13 admin |
| Additional legal information page | 1 |
| Local HTML/asset references | ${stat.linksChecked} passed; no broken local links |
| Main home sections | Home 1: 10; Home 2: 10 |
| Other major public pages | Each contains 5 or 6 main sections |
| Photography | ${photos} generated WebPs, ${stat.photoPlacements} placements, no reused photograph |
| Logo/icons | Original SVG header/footer/dashboard logos; SVG and 32px PNG favicon; 180/192/512px PNG icons |
| Responsive checks | ${browser.checks} combinations across ${browser.pages} required pages |
| Widths | ${browser.widths.join(", ")} px |
| Themes/directions | Light + dark; LTR + RTL, all widths on every required page |
| Page overflow failures | ${browser.failures.length} |
| Browser JavaScript errors | ${browser.pageErrors.length} |
| Missing resources / HTTP errors | ${browser.resources.length} |
| Workflow assertions | ${workflows.total} passed |
| Additional edge assertions | ${edges.total} passed |
| Automated accessibility | ${access.pages} pages × 2 themes; ${access.results.length} page/theme runs with violations |
| Charts | All five initialize; payments agree with shared financial data; filters update reports; theme/direction redraw correctly |
| Exports | CSV report downloaded and inspected; printable invoice saved as a PDF during QA |

## Functional coverage

Home dropdown, mobile navigation, persisted theme/RTL, hall capacity filters/reset, gallery filtering and Escape-close lightbox, journal search/pagination/empty states, contact validation and locally stored inbox entries, reply drafts, package/add-on estimates, new booking persistence and confirmation, client booking search/details, simulated installment payments, matching invoice balances, all five charts, admin status management, hall creation, date blocking, catering quantities/persistence, editable profile, notification states, report dates/CSV export, registration password matching, no password storage, password visibility, corrupt-storage recovery and mobile sidebar behavior.

Additional tests reject reserved/past dates and excess hall capacity; verify the embedded client booking form and single-step month navigation after hall changes; carry edited package/decoration prices into estimates; persist display settings; verify honest password-reset/newsletter states, distinct journal content, local comments, enabled chart tooltip plugin and local-data reset.

## Visual review

Ninety full-page screenshots were captured: every required page at 1440px light/LTR and 390px dark/RTL. Six contact sheets were inspected for all page layouts. Individual homepage, authentication and full admin charts were also inspected. Image decode checks load all lazy photographs for screenshots. Normal page browsing retains lazy loading below the fold.

The initial matrix found 320px overflow in the two homepage category grids. These were fixed and the matrix rerun. The accessibility audit found low-contrast small gold numbers, dark milestones and read-notification opacity. These were corrected and a subsequent full audit found no tagged WCAG 2 A/AA and WCAG 2.1 AA violations. This automated result is not a complete manual accessibility certification.

## Limits and launch requirements

- Verification used Chrome. Safari/Firefox/Edge were not independently audited. No Lighthouse score or Core Web Vitals measurement is claimed.
- Public metadata, venue identity, contact/map/social information and legal policies are explicit placeholders. Replace them with verified real data before launch.
- Authentication, password reset, email delivery, payments and live availability still need secure backend/provider integrations. No money, email, real reservation or external message is processed by this frontend.
- Browser Print / Save as PDF is supported; a direct-download PDF library is not bundled.
- One requested reference was inspected as source HTML; the other six were inaccessible through the retrieval tool. Reference computed layout and responsive behavior were not browser-verified. See reference-review.md.
- The legal-information page was included in local link/structure checks. The 45-page responsive/accessibility matrix covers the required pages.

## Evidence

- static-test-results.json
- browser-test-results.json
- workflow-test-results.json
- edge-test-results.json
- accessibility-test-results.json
- ../tests/screenshots/
- ../tests/contact-light-ltr-1.jpg through contact-dark-rtl-3.jpg
- ../tests/demo-invoice.pdf and ../tests/demo-report.csv

Run npm test for static verification. Start npm start in a separate terminal before npm run test:workflows, npm run test:edges, npm run test:responsive or npm run test:accessibility. Browser QA uses isolated profiles and does not modify real browser data.
`;
fs.writeFileSync("documentation/testing-report.md", text);
fs.writeFileSync(
  "documentation/task-checklist.md",
  `# Delivery checklist\n\n${["Project inspection: empty original folder; no unrelated work overwritten", "Design tokens, spacing, typography, light/dark and RTL", "Original logo, SVG/PNG favicon, application icons", "All 54 generated and optimized local photographs", "Both homepages with exactly ten sections", "Every required public page with five or six sections", "All authentication and utility pages", "All eleven client dashboard screens", "All thirteen admin dashboard screens", "Validated demo booking/payment/admin workflows", "Shared-data charts and financial totals", "Responsive matrix across thirteen widths and both themes/directions", "Automated accessibility audit and contrast corrections", "Source formatting, installation/customization/integration/credits/support guides", "Image inventory and license notices"].map((t) => "- [x] " + t).join("\n")}\n\nBackend services, real business configuration, independent cross-browser audits and marketplace/legal review are launch tasks, not implemented production services.\n`,
);
console.log("Wrote testing report and delivery checklist.");
