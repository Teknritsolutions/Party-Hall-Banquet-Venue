﻿# License and distribution notes

Original template source and generated branding/photographs were prepared for this requested project. The supplied third-party components retain their own MIT, ISC and SIL Open Font License terms; complete notices are in assets/vendor and assets/fonts.

No claim of marketplace acceptance, exclusive generated-image rights, trademark clearance or suitability for a particular commercial licensing arrangement is made. The recipient must choose an appropriate commercial template license and review the applicable generation-tool terms, marketplace rules and third-party redistribution notices before offering the template for sale. This notice does not relicense third-party components or unrelated files outside this folder.
